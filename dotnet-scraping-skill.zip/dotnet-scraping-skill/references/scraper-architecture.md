# Scraper Architecture Reference

Use this reference for structural or architectural changes.

## Recommended boundaries

A typical scraper can separate:

- `SourceClient` / adapter: request and source-specific transport concerns;
- `Parser`: HTML/JSON extraction;
- `Normalizer`: converts source data into stable application/domain models;
- `Persistence`: stores validated data and handles deduplication;
- `Orchestrator`: controls the execution flow, pagination, checkpoints, and cancellation.

Do not create all of these abstractions automatically. Follow the existing project structure and introduce a boundary only when it reduces coupling or isolates a real source concern.

## Idempotency

Use stable source identifiers plus a defined deduplication strategy. A rerun should not create duplicate business records.

## Provenance

When traceability matters, preserve source identity, retrieval time, and enough metadata to diagnose where a value came from.

## Scheduling

Keep schedules and execution orchestration separate from source-specific parsing. Scheduled jobs should be restartable and cancellation-aware.

## Persistence safety

Validate before write. Do not treat an empty or malformed scrape as authoritative unless the source contract explicitly says it is.
