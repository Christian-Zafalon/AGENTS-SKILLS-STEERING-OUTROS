# HTTP and Resilience Reference

Use this reference only for HTTP transport, retry, rate-limit, timeout, or concurrency work.

## .NET defaults

- Reuse `HttpClient` rather than creating one per request.
- Prefer `IHttpClientFactory` for named/typed clients and centralized configuration.
- Long-lived clients may use `SocketsHttpHandler.PooledConnectionLifetime` when DNS refresh matters.
- Every scrape operation should support `CancellationToken` and an explicit timeout.

## Retry policy

Retry only transient failures. Typical candidates include timeouts, connection failures, `408`, `429`, and selected `5xx` responses.

Use bounded retries with exponential backoff and jitter. Respect `Retry-After` when present.

Do not retry:

- deterministic parsing failures;
- invalid configuration;
- authentication/authorization failures;
- malformed requests;
- non-idempotent operations unless the operation is explicitly safe to repeat.

## Concurrency

Use a bounded concurrency policy per source. A faster scraper is not better if it increases throttling, failures, or bans.

Prefer framework-supported rate/concurrency limiters over ad-hoc delays. Keep the limit configurable.
