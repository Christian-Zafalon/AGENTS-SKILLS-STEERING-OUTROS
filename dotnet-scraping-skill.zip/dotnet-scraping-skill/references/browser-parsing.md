# Browser Parsing Reference

Use this reference only when browser automation is required.

## When to use a browser

Use Playwright/.NET when data or actions depend on JavaScript execution, browser state, interaction, navigation, or content unavailable through direct HTTP.

Prefer direct HTTP when it can provide the same data more simply and reliably.

## Locator strategy

Prefer stable, user-facing, or explicit-contract locators such as role, label, text, placeholder, and test id where appropriate.

Use CSS/XPath only when necessary and keep selectors short and specific. Avoid selectors tightly coupled to DOM position or generated class names.

## Dynamic content

Prefer Playwright's locator waiting and assertions over arbitrary sleeps. Wait for the condition that proves the required content is ready.

Keep browser lifecycle management outside source parsing logic.

## Failure diagnostics

For selector failures, capture useful evidence when the project supports it: URL, source, selector/operation, and relevant page state. Avoid storing sensitive session data.
