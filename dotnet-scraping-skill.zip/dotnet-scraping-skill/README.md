# dotnet-scraping Skill

Cursor Agent Skill for C#/.NET scraping projects.

## Install in a project

Place this directory at:

`.cursor/skills/dotnet-scraping/`

Result:

```text
.cursor/
└── skills/
    └── dotnet-scraping/
        ├── SKILL.md
        └── references/
            ├── browser-parsing.md
            ├── http-resilience.md
            └── scraper-architecture.md
```

The main `SKILL.md` is intentionally compact. Detailed guidance is in `references/` so Cursor can load it only when needed.

## Manual invocation

Use `/dotnet-scraping` in Agent chat when you want to explicitly activate the skill.
