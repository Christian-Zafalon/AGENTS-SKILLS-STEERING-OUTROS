---
name: dotnet-scraping
description: Build, review, debug, and evolve C#/.NET web-scraping systems. Use when implementing source adapters, HTTP fetching, browser automation, HTML parsing, data normalization, pagination, retries, rate limits, persistence, scheduling, observability, or scraping tests. First inspect the existing project patterns and change only the relevant files.
---

# .NET Scraping

## Goal

Build reliable, maintainable, polite, and observable scrapers in C#/.NET while preserving the project's existing architecture and conventions.

## Context-Efficient Workflow

1. Inspect the solution structure and locate the scraper entry point, source adapter, parser, persistence boundary, configuration, and tests.
2. Read only the files needed for the requested change. Prefer targeted search over opening large unrelated files.
3. Reuse existing abstractions, naming, DI, logging, retry, and persistence patterns before introducing new ones.
4. Make the smallest change that solves the task.
5. Run the narrowest relevant build/test first, then broader validation when needed.
6. Do not redesign the architecture unless the current structure has no coherent pattern or the task requires it.

## Scraping Strategy

- Prefer direct HTTP (`HttpClient`) when the required data is available from HTML, JSON, feeds, or public endpoints.
- Use browser automation such as Playwright only when client-side rendering, interaction, navigation, or browser state is required.
- Keep fetching, parsing, normalization, and persistence as separate responsibilities.
- Prefer source-specific adapters so a website change affects one integration rather than the whole system.
- Treat external HTML/API contracts as unstable. Isolate selectors, endpoint paths, and source-specific assumptions.

## HTTP and Resilience

- Reuse `HttpClient`; never create and dispose a new client per request.
- Prefer `IHttpClientFactory` or a long-lived client with an appropriate `PooledConnectionLifetime`.
- Set explicit request timeouts and cancellation support.
- Apply bounded retries only to transient failures. Use exponential backoff with jitter where appropriate.
- Do not blindly retry non-idempotent operations.
- Respect `429`, `Retry-After`, server errors, and source-specific limits.
- Bound outbound concurrency per source. Throughput is secondary to source safety and reliability.
- Never use retries to hide deterministic parsing or validation failures.

## Rate Limiting and Politeness

- Rate-limit requests per target/source when required.
- Prefer a shared limiter over scattered `Task.Delay` calls.
- Make concurrency, delay, and retry policies configurable.
- Avoid request bursts caused by parallel pagination or scheduled jobs.
- Do not bypass authentication, CAPTCHAs, access controls, or technical restrictions.
- Follow applicable terms, robots directives, contractual restrictions, and source policies.

## Parsing

- Keep selectors and parsing rules close to the source adapter.
- Parse defensively: missing nodes, changed labels, empty collections, malformed values, and unexpected formats are normal external failures.
- Fail with actionable diagnostics when required data is missing; do not silently manufacture values.
- Normalize source data before passing it to domain/application code.
- Prefer typed models over `object`, `dynamic`, or unstructured dictionaries when the contract is known.
- For Playwright, prefer resilient user-facing or explicit-contract locators over brittle CSS/XPath chains.

## Pagination and Incremental Processing

- Make pagination explicit and bounded.
- Stop on source-defined end conditions, empty pages, repeated cursors, or configured safety limits.
- Avoid downloading the same page repeatedly within one execution.
- Prefer incremental/checkpointed processing for large sources when supported by the project.
- Make runs idempotent so retries or restarts do not create duplicate records.

## Data Integrity

- Validate data before persistence.
- Preserve source identifiers, retrieval timestamps, and relevant provenance when the project requires traceability.
- Separate raw/source models from normalized/domain models when transformations are non-trivial.
- Treat partial or stale source data explicitly; never silently overwrite trusted data with an invalid scrape.

## Observability

Log enough to answer: which source, which item/page, when, duration, outcome, and failure category.

- Use structured logging.
- Include correlation/run identifiers when the project supports them.
- Avoid logging secrets, tokens, cookies, personal data, or full sensitive payloads.
- Measure request failures, throttling, parsing failures, item counts, and execution duration when practical.

## Testing

Prioritize deterministic tests for:

- parsers and selectors using saved fixtures;
- normalization and validation;
- pagination and retry decisions;
- duplicate/idempotency behavior;
- source-specific failure cases.

Do not require live websites for normal unit tests. Use integration tests against external systems only when the project explicitly supports them.

## Change Safety

Before changing a scraper, identify whether the change affects:

- source selectors or contracts;
- request headers/cookies/session state;
- pagination;
- retry/rate-limit behavior;
- normalized output;
- persistence or deduplication;
- scheduling or parallelism.

Preserve existing behavior unless the task explicitly changes the contract. When a source is ambiguous or unstable, prefer explicit validation and diagnostics over speculative fixes.

## References

Load only the reference that matches the current task:

- `references/http-resilience.md` — HttpClient lifetime, timeouts, retries, rate limiting, and concurrency.
- `references/browser-parsing.md` — Playwright and robust browser-based extraction.
- `references/scraper-architecture.md` — source adapters, parsing boundaries, persistence, idempotency, and observability.
