# Cursor Rules — Clean Code for C#/.NET

This package converts the provided Kiro `clean-code` steering into focused Cursor Project Rules (`.mdc`).

## Rule strategy

- `clean-code-core.mdc` — **Always Apply**. Kept intentionally small because always-applied rules consume context on every agent interaction.
- `clean-code-functions-oop.mdc` — **Agent Requested**. Method design, classes, objects, composition, and variables.
- `clean-code-errors-concurrency.mdc` — **Agent Requested**. Exceptions, null handling, async/concurrency, mutable/shared state.
- `clean-code-tests.mdc` — **Agent Requested**. Unit tests, AAA, determinism, isolation, and test naming.
- `clean-code-architecture-solid.mdc` — **Agent Requested**. Existing architecture first, then SOLID and dependency boundaries.
- `clean-code-documentation-formatting.mdc` — **Agent Requested**. Comments, XML docs, formatting, readability, and source organization.

## Why it is split this way

Cursor recommends rules that are focused, actionable, scoped, and composable. It also recommends referencing canonical files instead of copying large guides and adding rules when the agent repeatedly makes a mistake.

The core rule is therefore small and always active. Specialized rules are available to the Agent only when their description is relevant, reducing unnecessary static context.

## C#/.NET adaptations

The original concepts were translated to C#/.NET terminology, including:

- `Task` / `Task<T>` and async/await
- exceptions and `ProblemDetails`
- dependency injection
- DTOs / records / value objects
- ASP.NET Core boundaries
- EF Core / persistence boundaries
- xUnit-style testing

The rules intentionally avoid forcing a specific framework pattern when the existing repository already has a defined convention.
