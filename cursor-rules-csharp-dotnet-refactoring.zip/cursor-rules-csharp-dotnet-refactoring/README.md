# Cursor Rules — C#/.NET Refactoring

These Rules convert the provided refactoring steering into Cursor-friendly `.mdc` files.

## Design goals

- English-only Rules.
- C#/.NET-specific terminology and examples.
- Minimal always-applied context.
- Focused agent-selected Rules for specialized refactorings.
- Behavior preservation as the default contract.
- Respect existing project architecture and conventions before introducing abstractions.

## Files

- `refactoring-core.mdc` — always applied; compact baseline for safe refactoring.
- `refactoring-composing-methods.mdc` — method decomposition and signature cleanup.
- `refactoring-moving-data.mdc` — moving responsibilities, data encapsulation, parameter objects, and type extraction.
- `refactoring-conditionals-calls.mdc` — conditionals, guard clauses, method contracts, and command/query separation.
- `refactoring-generalization-cleanup.mdc` — inheritance, composition, dead code, algorithms, loops, and type-code replacement.

## Important behavior

A refactoring must not intentionally change externally observable behavior. If equivalence is uncertain, treat the work as a design or behavior change rather than a pure refactoring.

The Rules deliberately avoid rigid thresholds such as a fixed parameter count or a blanket rule that every `switch` must become polymorphism. Such thresholds are signals, not automatic refactoring commands.
