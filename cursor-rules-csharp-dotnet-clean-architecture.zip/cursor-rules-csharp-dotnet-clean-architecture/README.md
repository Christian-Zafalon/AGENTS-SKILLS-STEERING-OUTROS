# Cursor Rules — C#/.NET Clean Architecture

These rules were split by architectural responsibility to keep Cursor context focused.

## Files

- `clean-architecture-core.mdc` — small auto-attached baseline for C# files.
- `clean-architecture-domain.mdc` — Domain entities, value objects, exceptions, aggregates, events.
- `clean-architecture-application.mdc` — use cases, ports, DTOs, orchestration, transactions.
- `clean-architecture-adapters.mdc` — ASP.NET Core controllers/endpoints and presentation boundaries.
- `clean-architecture-infrastructure.mdc` — EF Core/Dapper, gateways, messaging, cache, DI, startup.
- `clean-architecture-mapping-tests.mdc` — mapping and testing boundaries.

## Why this structure

Cursor's current guidance is to keep Rules short and focused, use file scoping when practical, and prefer dynamic context discovery for larger or specialized knowledge. The core rule is intentionally small and scoped to `**/*.cs`; the specialized rules are agent-selected with concise descriptions.

Place the files under:

`.cursor/rules/`
