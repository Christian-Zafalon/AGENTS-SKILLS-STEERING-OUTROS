# Cursor Rules — C#/.NET Code Smells

This package converts the original code-smells steering into focused Cursor `.mdc` Project Rules.

## Structure

- `code-smells-core.mdc` — always applied; intentionally small.
- `code-smells-structure.mdc` — large methods/classes, long parameter lists, duplication, dead code.
- `control-flow.mdc` — excessive conditionals, large switches, boolean flags, deep nesting, hidden side effects.
- `coupling-maintainability.mdc` — cyclic dependencies, excessive coupling, responsibility leakage, misleading comments.

## Design choices

The core rule is always applied because the original steering requires code-smell awareness during implementation, bug fixing, refactoring, and review. Detailed smell-specific guidance is agent-selected to reduce static context.

The rules are written for C#/.NET and intentionally avoid rigid numeric thresholds. For example, parameter count is a signal rather than an automatic reason to introduce a DTO.

The rules preserve an important constraint from the original steering: identified smells should be corrected through appropriate refactoring, using `refactoring-mf` guidance when that rule exists in the project.

Behavior and architecture changes are not silently introduced merely to remove a smell. Local, behavior-preserving refactorings should be performed automatically; larger architectural changes should surface the trade-off first.
